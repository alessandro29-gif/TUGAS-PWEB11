<?php
require_once "auth.php";
wajib_login();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0);
    $nama = trim($_POST["nama"] ?? ""); $alamat = trim($_POST["alamat"] ?? ""); $hp = trim($_POST["no_hp"] ?? "");
    if ($nama == "" || $alamat == "" || !preg_match('/^[0-9+]{8,15}$/', $hp)) {
        $_SESSION["pesan"] = "Data tidak valid. Nama dan alamat wajib diisi, no HP 8-15 digit angka.";
        $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0) {
        q("UPDATE pelanggan SET nama=?, alamat=?, no_hp=? WHERE id_pelanggan=?", "sssi", [$nama, $alamat, $hp, $id]);
        $_SESSION["pesan"] = "Data pelanggan berhasil diubah.";
    } else {
        q("INSERT INTO pelanggan (nama, alamat, no_hp) VALUES (?,?,?)", "sss", [$nama, $alamat, $hp]);
        $_SESSION["pesan"] = "Pelanggan baru berhasil ditambahkan.";
    }
    header("Location: pelanggan.php"); exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    try {
        q("DELETE FROM pelanggan WHERE id_pelanggan=?", "i", [(int)$_POST["hapus"]]);
        $_SESSION["pesan"] = "Pelanggan berhasil dihapus.";
    } catch (Exception $e) {
        $_SESSION["pesan"] = "Pelanggan tidak bisa dihapus karena sudah punya transaksi.";
        $_SESSION["pesan_galat"] = 1;
    }
    header("Location: pelanggan.php"); exit;
}

$edit = null;
if (isset($_GET["edit"])) { $edit = satu("SELECT * FROM pelanggan WHERE id_pelanggan=?", "i", [(int)$_GET["edit"]]); }
$cari = trim($_GET["cari"] ?? "");
$data = semua("SELECT * FROM pelanggan WHERE nama LIKE ? OR no_hp LIKE ? ORDER BY id_pelanggan DESC", "ss", ["%$cari%", "%$cari%"]);

$halaman = "pelanggan";
$judul_hero = "Pelanggan";
$teks_hero = "Tambah, ubah, hapus, dan cari data pelanggan.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Pelanggan" : "Tambah Pelanggan"; ?></h3>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_pelanggan"] : 0; ?>">
<div class="row">
<div class="col-sm-4 form-group"><label for="nama">Nama</label><input class="form-control" id="nama" name="nama" value="<?php echo e($edit["nama"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="alamat">Alamat</label><input class="form-control" id="alamat" name="alamat" value="<?php echo e($edit["alamat"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="no_hp">No HP</label><input class="form-control" id="no_hp" name="no_hp" inputmode="tel" value="<?php echo e($edit["no_hp"] ?? ""); ?>" required></div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="pelanggan.php">Batal</a><?php } ?>
</form>
</div>

<form method="get" class="alat-bar">
<input type="search" class="form-control cari" name="cari" placeholder="Cari nama atau no HP" value="<?php echo e($cari); ?>" aria-label="Cari pelanggan">
<button type="submit" class="btn-sekunder">Cari</button>
</form>
<p class="jumlah-hasil"><?php echo count($data); ?> pelanggan</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:700px">
<thead><tr><th>ID</th><th>Nama</th><th>Alamat</th><th>No HP</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $p) { ?>
<tr>
<td><?php echo $p["id_pelanggan"]; ?></td>
<td class="nama"><?php echo e($p["nama"]); ?></td>
<td><?php echo e($p["alamat"]); ?></td>
<td><?php echo e($p["no_hp"]); ?></td>
<td class="aksi-baris">
<a class="tombol-kecil" href="pelanggan.php?edit=<?php echo $p["id_pelanggan"]; ?>#nama" style="text-decoration:none">Ubah</a>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus pelanggan ini?')"><button type="submit" name="hapus" value="<?php echo $p["id_pelanggan"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td>
</tr>
<?php } ?>
<?php if (!$data) { ?><tr><td colspan="5" class="kosong">Data tidak ditemukan.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.nama.value.trim()=="" || f.alamat.value.trim()==""){ err.textContent="Nama dan alamat wajib diisi."; return false; }
if(!/^[0-9+]{8,15}$/.test(f.no_hp.value.trim())){ err.textContent="No HP harus 8-15 digit angka."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
