<?php
require_once "auth.php";
wajib_login();
$t = satu("SELECT t.*, p.nama, p.no_hp, l.nama_layanan, l.harga_per_kg FROM transaksi t JOIN pelanggan p ON p.id_pelanggan = t.id_pelanggan JOIN layanan l ON l.id_layanan = t.id_layanan WHERE t.id_transaksi = ?", "i", [(int)($_GET["id"] ?? 0)]);
if (!$t) { header("Location: transaksi.php"); exit; }
$halaman = "transaksi";
$judul_hero = "Nota";
$teks_hero = "";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="nota">
<h2>LaundryCrafty</h2>
<p class="tengah">Surabaya, Jawa Timur</p>
<table>
<tr><td>No nota</td><td>#<?php echo str_pad($t["id_transaksi"], 5, "0", STR_PAD_LEFT); ?></td></tr>
<tr><td>Pelanggan</td><td><?php echo e($t["nama"]); ?></td></tr>
<tr><td>No HP</td><td><?php echo e($t["no_hp"]); ?></td></tr>
<tr><td>Layanan</td><td><?php echo e($t["nama_layanan"]); ?></td></tr>
<tr><td>Berat</td><td><?php echo e($t["berat"] + 0); ?> kg x <?php echo rupiah($t["harga_per_kg"]); ?></td></tr>
<tr><td>Masuk</td><td><?php echo date("d/m/Y", strtotime($t["tanggal_masuk"])); ?></td></tr>
<tr><td>Selesai</td><td><?php echo date("d/m/Y", strtotime($t["tanggal_selesai"])); ?></td></tr>
<tr><td>Status</td><td><?php echo e($t["status"]); ?></td></tr>
<tr class="jumlah"><td>Total</td><td><?php echo rupiah($t["total_harga"]); ?></td></tr>
</table>
<p class="tengah" style="margin-top:14px">Terima kasih sudah mencuci di LaundryCrafty!</p>
</div>
<p class="tidak-cetak" style="text-align:center;margin-top:24px">
<button type="button" class="btn-utama" onclick="window.print()">Cetak Nota</button>
<a class="btn-sekunder" href="transaksi.php">Kembali</a>
</p>
</div>
</section>
<?php include "footer.php"; ?>
