<?php
require_once "auth.php";
if (isset($_SESSION["id_user"])) { header("Location: index.php"); exit; }
$galat = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";
    if ($username == "" || $password == "") {
        $galat = "Username dan password wajib diisi.";
    } else {
        $u = satu("SELECT * FROM user WHERE username = ?", "s", [$username]);
        if ($u && password_verify($password, $u["password"])) {
            session_regenerate_id(true);
            $_SESSION["id_user"] = $u["id_user"];
            $_SESSION["username"] = $u["username"];
            $_SESSION["role"] = $u["role"];
            header("Location: index.php"); exit;
        }
        $galat = "Username atau password salah.";
    }
}
$halaman = "login";
$judul_hero = "Masuk";
$teks_hero = "Silakan login sebagai admin atau kasir.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form kartu-login">
<?php if($galat != ""){ ?><div class="kotak-info galat" role="alert"><?php echo e($galat); ?></div><?php } ?>
<form method="post" novalidate onsubmit="return cek(this)">
<div class="form-group">
<label for="username">Username</label>
<input type="text" class="form-control" id="username" name="username" value="<?php echo e($_POST["username"] ?? ""); ?>" required autofocus>
</div>
<div class="form-group">
<label for="password">Password</label>
<input type="password" class="form-control" id="password" name="password" required>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" class="btn-utama">Masuk</button>
</form>
</div>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.username.value.trim()=="" || f.password.value==""){ err.textContent="Username dan password wajib diisi."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
