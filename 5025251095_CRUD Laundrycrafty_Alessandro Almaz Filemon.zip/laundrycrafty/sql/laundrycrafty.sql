-- LaundryCrafty - struktur dan data awal
CREATE DATABASE IF NOT EXISTS laundrycrafty CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE laundrycrafty;

DROP TABLE IF EXISTS transaksi;
DROP TABLE IF EXISTS pelanggan;
DROP TABLE IF EXISTS layanan;
DROP TABLE IF EXISTS user;

CREATE TABLE pelanggan (
  id_pelanggan INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  alamat VARCHAR(255) NOT NULL,
  no_hp VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE layanan (
  id_layanan INT AUTO_INCREMENT PRIMARY KEY,
  nama_layanan VARCHAR(50) NOT NULL,
  harga_per_kg INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE transaksi (
  id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
  id_pelanggan INT NOT NULL,
  id_layanan INT NOT NULL,
  tanggal_masuk DATE NOT NULL,
  tanggal_selesai DATE NOT NULL,
  berat DECIMAL(6,2) NOT NULL,
  total_harga INT NOT NULL,
  status ENUM('Proses','Selesai','Sudah Diambil') NOT NULL DEFAULT 'Proses',
  FOREIGN KEY (id_pelanggan) REFERENCES pelanggan(id_pelanggan),
  FOREIGN KEY (id_layanan) REFERENCES layanan(id_layanan)
) ENGINE=InnoDB;

CREATE TABLE user (
  id_user INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','kasir') NOT NULL
) ENGINE=InnoDB;

-- password: admin123 dan kasir123 (sudah di-hash dengan password_hash)
INSERT INTO user (username, password, role) VALUES
('admin', '$2y$10$YGwjOF3O5deBKBSpnYnTQuFddvbvcy4e/Hoe0uO92VfIxHnX48b1S', 'admin'),
('kasir', '$2y$10$TthOI4L4J5H5quyfh/aoY.ChrH6lMEPuaoKMpdC8.4Kzjxkyfe9w2', 'kasir');

INSERT INTO layanan (nama_layanan, harga_per_kg) VALUES
('Cuci Kering', 5000), ('Cuci Setrika', 7000), ('Express', 10000);

INSERT INTO pelanggan (nama, alamat, no_hp) VALUES
('Budi Santoso', 'Jl. Keputih No. 12, Surabaya', '081234567890'),
('Siti Rahma', 'Jl. Mulyorejo No. 5, Surabaya', '081298765432'),
('Dewi Lestari', 'Jl. Manyar Kertoarjo No. 8, Surabaya', '085712345678');

INSERT INTO transaksi (id_pelanggan, id_layanan, tanggal_masuk, tanggal_selesai, berat, total_harga, status) VALUES
(1, 2, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 2 DAY), 3.5, 24500, 'Proses'),
(2, 1, DATE_SUB(CURDATE(), INTERVAL 1 DAY), CURDATE(), 4.0, 20000, 'Selesai'),
(3, 3, DATE_SUB(CURDATE(), INTERVAL 2 DAY), DATE_SUB(CURDATE(), INTERVAL 1 DAY), 2.0, 20000, 'Sudah Diambil');
