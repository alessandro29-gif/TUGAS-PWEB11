<?php
require_once "auth.php";
wajib_login();
$pelanggan = semua("SELECT id_pelanggan, nama FROM pelanggan ORDER BY nama");
$layanan = semua("SELECT * FROM layanan ORDER BY id_layanan");

$galat = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idp = (int)($_POST["id_pelanggan"] ?? 0);
    $idl = (int)($_POST["id_layanan"] ?? 0);
    $masuk = $_POST["tanggal_masuk"] ?? "";
    $selesai = $_POST["tanggal_selesai"] ?? "";
    $berat = (float)str_replace(",", ".", $_POST["berat"] ?? "0");
    $l = satu("SELECT harga_per_kg FROM layanan WHERE id_layanan=?", "i", [$idl]);
    $p = satu("SELECT id_pelanggan FROM pelanggan WHERE id_pelanggan=?", "i", [$idp]);
    if (!$p || !$l) {
        $galat = "Pilih pelanggan dan layanan yang valid.";
    } elseif ($masuk == "" || $selesai == "" || $selesai < $masuk) {
        $galat = "Tanggal selesai tidak boleh lebih awal dari tanggal masuk.";
    } elseif ($berat <= 0 || $berat > 100) {
        $galat = "Berat harus lebih dari 0 dan maksimal 100 kg.";
    } else {
        $total = (int)round($berat * $l["harga_per_kg"]);   // dihitung di server
        $st = q("INSERT INTO transaksi (id_pelanggan, id_layanan, tanggal_masuk, tanggal_selesai, berat, total_harga, status) VALUES (?,?,?,?,?,?,'Proses')", "iissdi", [$idp, $idl, $masuk, $selesai, $berat, $total]);
        $_SESSION["pesan"] = "Transaksi tersimpan. Total: " . rupiah($total);
        header("Location: transaksi.php"); exit;
    }
}
$halaman = "transaksi";
$judul_hero = "Transaksi Baru";
$teks_hero = "Total harga dihitung otomatis dari berat dan layanan.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form">
<?php if ($galat != "") { ?><div class="kotak-info galat" role="alert"><?php echo e($galat); ?></div><?php } ?>
<form method="post" novalidate onsubmit="return cek(this)">
<div class="row">
<div class="col-sm-6 form-group">
<label for="id_pelanggan">Pelanggan</label>
<select class="form-control" id="id_pelanggan" name="id_pelanggan" required>
<option value="">-- Pilih pelanggan --</option>
<?php foreach ($pelanggan as $p) { ?><option value="<?php echo $p["id_pelanggan"]; ?>"<?php if (($_POST["id_pelanggan"] ?? "") == $p["id_pelanggan"]) echo " selected"; ?>><?php echo e($p["nama"]); ?></option><?php } ?>
</select>
<p class="petunjuk">Belum terdaftar? <a href="pelanggan.php">Tambah pelanggan dulu</a>.</p>
</div>
<div class="col-sm-6 form-group">
<label for="id_layanan">Layanan</label>
<select class="form-control" id="id_layanan" name="id_layanan" required>
<option value="" data-harga="0">-- Pilih layanan --</option>
<?php foreach ($layanan as $l) { ?><option value="<?php echo $l["id_layanan"]; ?>" data-harga="<?php echo $l["harga_per_kg"]; ?>"<?php if (($_POST["id_layanan"] ?? "") == $l["id_layanan"]) echo " selected"; ?>><?php echo e($l["nama_layanan"]) . " - " . rupiah($l["harga_per_kg"]) . "/kg"; ?></option><?php } ?>
</select>
</div>
</div>
<div class="row">
<div class="col-sm-4 form-group"><label for="tanggal_masuk">Tanggal masuk</label><input type="date" class="form-control" id="tanggal_masuk" name="tanggal_masuk" value="<?php echo e($_POST["tanggal_masuk"] ?? date("Y-m-d")); ?>" required></div>
<div class="col-sm-4 form-group"><label for="tanggal_selesai">Tanggal selesai</label><input type="date" class="form-control" id="tanggal_selesai" name="tanggal_selesai" value="<?php echo e($_POST["tanggal_selesai"] ?? date("Y-m-d", strtotime("+2 day"))); ?>" required></div>
<div class="col-sm-4 form-group"><label for="berat">Berat (kg)</label><input type="number" step="0.1" min="0.1" max="100" class="form-control" id="berat" name="berat" value="<?php echo e($_POST["berat"] ?? ""); ?>" required></div>
</div>
<div class="form-group"><span class="judul-isian">Total harga</span><span class="total-tampil" id="total">Rp 0</span></div>
<p class="pesan-error" id="err"></p>
<button type="submit" class="btn-utama">Simpan Transaksi</button>
<a class="btn-sekunder" href="transaksi.php">Batal</a>
</form>
</div>
</div>
</section>
<script>
var elL = document.getElementById("id_layanan"), elB = document.getElementById("berat"), elT = document.getElementById("total");
function hitung(){
var harga = Number(elL.options[elL.selectedIndex].getAttribute("data-harga")) || 0;
var berat = parseFloat(elB.value) || 0;
elT.textContent = "Rp " + Math.round(harga * berat).toLocaleString("id-ID");
}
elL.addEventListener("change", hitung); elB.addEventListener("input", hitung); hitung();
function cek(f){
var err = document.getElementById("err");
if(!f.id_pelanggan.value || !f.id_layanan.value){ err.textContent="Pilih pelanggan dan layanan."; return false; }
if(!(parseFloat(f.berat.value) > 0)){ err.textContent="Berat harus lebih dari 0."; return false; }
if(f.tanggal_selesai.value < f.tanggal_masuk.value){ err.textContent="Tanggal selesai tidak boleh lebih awal dari tanggal masuk."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
