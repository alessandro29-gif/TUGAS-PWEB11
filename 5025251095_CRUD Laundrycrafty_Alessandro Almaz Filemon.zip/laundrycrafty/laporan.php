<?php
require_once "auth.php";
wajib_login("admin");
$dari = $_GET["dari"] ?? date("Y-m-01");
$sampai = $_GET["sampai"] ?? date("Y-m-d");
$periode = $_GET["periode"] ?? "harian";
if (!in_array($periode, ["harian", "mingguan", "bulanan"], true)) { $periode = "harian"; }

if ($periode == "harian") {
    $kelompok = "DATE_FORMAT(tanggal_masuk, '%d/%m/%Y')"; $urut = "tanggal_masuk";
} elseif ($periode == "mingguan") {
    $kelompok = "CONCAT('Minggu ke-', WEEK(tanggal_masuk, 1), ' (', YEAR(tanggal_masuk), ')')"; $urut = "YEARWEEK(tanggal_masuk, 1)";
} else {
    $kelompok = "DATE_FORMAT(tanggal_masuk, '%m/%Y')"; $urut = "DATE_FORMAT(tanggal_masuk, '%Y-%m')";
}
$baris = semua("SELECT $kelompok AS periode, COUNT(*) AS jumlah, SUM(berat) AS berat, SUM(total_harga) AS pendapatan FROM transaksi WHERE tanggal_masuk BETWEEN ? AND ? GROUP BY $urut, periode ORDER BY $urut", "ss", [$dari, $sampai]);
$total = 0; $jumlah = 0;
foreach ($baris as $b) { $total += $b["pendapatan"]; $jumlah += $b["jumlah"]; }

$halaman = "laporan";
$judul_hero = "Laporan";
$teks_hero = "Pendapatan harian, mingguan, dan bulanan.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<form method="get" class="bar-filter">
<div class="form-group"><label for="dari">Dari</label><input type="date" class="form-control" id="dari" name="dari" value="<?php echo e($dari); ?>"></div>
<div class="form-group"><label for="sampai">Sampai</label><input type="date" class="form-control" id="sampai" name="sampai" value="<?php echo e($sampai); ?>"></div>
<div class="form-group"><label for="periode">Periode</label>
<select class="form-control" id="periode" name="periode">
<?php foreach (["harian", "mingguan", "bulanan"] as $p) { ?><option value="<?php echo $p; ?>"<?php if ($periode == $p) echo " selected"; ?>><?php echo ucfirst($p); ?></option><?php } ?>
</select></div>
<button type="submit" class="btn-utama">Tampilkan</button>
</form>
<div class="baris-sama">
<div class="col-sm-6"><div class="kartu-statistik bulan"><div class="nilai"><?php echo rupiah($total); ?></div><p class="label">Total pendapatan</p></div></div>
<div class="col-sm-6"><div class="kartu-statistik biru"><div class="nilai"><?php echo $jumlah; ?></div><p class="label">Jumlah transaksi</p></div></div>
</div>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:560px">
<thead><tr><th>Periode</th><th>Transaksi</th><th>Berat (kg)</th><th class="angka-kanan">Pendapatan</th></tr></thead>
<tbody>
<?php foreach ($baris as $b) { ?>
<tr><td class="nama"><?php echo e($b["periode"]); ?></td><td><?php echo $b["jumlah"]; ?></td><td><?php echo e($b["berat"] + 0); ?></td><td class="angka-kanan"><?php echo rupiah($b["pendapatan"]); ?></td></tr>
<?php } ?>
<?php if (!$baris) { ?><tr><td colspan="4" class="kosong">Tidak ada data pada rentang tanggal ini.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<?php include "footer.php"; ?>
