<?php
session_start();
require_once "koneksi.php";

function wajib_login($role = "") {
    if (!isset($_SESSION["id_user"])) { header("Location: login.php"); exit; }
    if ($role != "" && $_SESSION["role"] != $role) { header("Location: index.php"); exit; }
}
function e($teks) { return htmlspecialchars((string)$teks, ENT_QUOTES, "UTF-8"); }
function rupiah($angka) { return "Rp " . number_format((int)$angka, 0, ",", "."); }
function kelas_status($s) {
    if ($s == "Proses") return "lencana-proses";
    if ($s == "Selesai") return "lencana-selesai";
    return "lencana-diambil";
}

function q($sql, $tipe = "", $param = []) {
    global $koneksi;
    $st = mysqli_prepare($koneksi, $sql);
    if ($tipe != "") { mysqli_stmt_bind_param($st, $tipe, ...$param); }
    mysqli_stmt_execute($st);
    $hasil = mysqli_stmt_get_result($st);
    return $hasil === false ? $st : $hasil;
}
function semua($sql, $tipe = "", $param = []) {
    $r = q($sql, $tipe, $param);
    return mysqli_fetch_all($r, MYSQLI_ASSOC);
}
function satu($sql, $tipe = "", $param = []) {
    $r = q($sql, $tipe, $param);
    return mysqli_fetch_assoc($r);
}
