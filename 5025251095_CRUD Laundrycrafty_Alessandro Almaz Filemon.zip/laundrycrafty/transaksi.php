<?php
require_once "auth.php";
wajib_login();
$admin = $_SESSION["role"] == "admin";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["ubah_status"])) {
    $status = $_POST["status"] ?? "";
    if (in_array($status, ["Proses", "Selesai", "Sudah Diambil"], true)) {
        q("UPDATE transaksi SET status=? WHERE id_transaksi=?", "si", [$status, (int)$_POST["ubah_status"]]);
        $_SESSION["pesan"] = "Status cucian diperbarui.";
    }
    header("Location: transaksi.php?" . http_build_query(["cari" => $_POST["cari"] ?? "", "tanggal" => $_POST["tanggal"] ?? ""])); exit;
}
if ($admin && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    q("DELETE FROM transaksi WHERE id_transaksi=?", "i", [(int)$_POST["hapus"]]);
    $_SESSION["pesan"] = "Transaksi berhasil dihapus.";
    header("Location: transaksi.php"); exit;
}

$cari = trim($_GET["cari"] ?? "");
$tanggal = trim($_GET["tanggal"] ?? "");
$sql = "SELECT t.*, p.nama, l.nama_layanan FROM transaksi t JOIN pelanggan p ON p.id_pelanggan = t.id_pelanggan JOIN layanan l ON l.id_layanan = t.id_layanan WHERE p.nama LIKE ?";
$tipe = "s"; $param = ["%$cari%"];
if ($tanggal != "") { $sql .= " AND t.tanggal_masuk = ?"; $tipe .= "s"; $param[] = $tanggal; }
$data = semua($sql . " ORDER BY t.id_transaksi DESC", $tipe, $param);

$halaman = "transaksi";
$judul_hero = "Transaksi";
$teks_hero = "Catat cucian masuk, ubah status, dan cetak nota.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<form method="get" class="alat-bar">
<input type="search" class="form-control cari" name="cari" placeholder="Cari nama pelanggan" value="<?php echo e($cari); ?>" aria-label="Cari nama pelanggan">
<input type="date" class="form-control saring" name="tanggal" value="<?php echo e($tanggal); ?>" aria-label="Tanggal masuk">
<button type="submit" class="btn-sekunder">Cari</button>
<a class="btn-utama" href="transaksi-form.php">+ Transaksi Baru</a>
</form>
<p class="jumlah-hasil"><?php echo count($data); ?> transaksi</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:980px">
<thead><tr><th>No</th><th>Pelanggan</th><th>Layanan</th><th>Masuk</th><th>Selesai</th><th>Berat</th><th>Total</th><th>Status</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $t) { ?>
<tr>
<td><?php echo $t["id_transaksi"]; ?></td>
<td class="nama"><?php echo e($t["nama"]); ?></td>
<td><?php echo e($t["nama_layanan"]); ?></td>
<td><?php echo date("d/m/Y", strtotime($t["tanggal_masuk"])); ?></td>
<td><?php echo date("d/m/Y", strtotime($t["tanggal_selesai"])); ?></td>
<td><?php echo e($t["berat"] + 0); ?> kg</td>
<td><?php echo rupiah($t["total_harga"]); ?></td>
<td>
<form method="post" class="form-status">
<input type="hidden" name="cari" value="<?php echo e($cari); ?>"><input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">
<select name="status" aria-label="Status cucian">
<?php foreach (["Proses", "Selesai", "Sudah Diambil"] as $s) { ?>
<option<?php if ($t["status"] == $s) echo " selected"; ?>><?php echo $s; ?></option>
<?php } ?>
</select>
<button type="submit" name="ubah_status" value="<?php echo $t["id_transaksi"]; ?>" class="tombol-kecil">Ubah</button>
</form>
</td>
<td class="aksi-baris">
<a class="tombol-kecil" href="nota.php?id=<?php echo $t["id_transaksi"]; ?>" style="text-decoration:none">Nota</a>
<?php if ($admin) { ?>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus transaksi ini?')"><button type="submit" name="hapus" value="<?php echo $t["id_transaksi"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
<?php } ?>
</td>
</tr>
<?php } ?>
<?php if (!$data) { ?><tr><td colspan="9" class="kosong">Belum ada transaksi yang cocok.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<?php include "footer.php"; ?>
