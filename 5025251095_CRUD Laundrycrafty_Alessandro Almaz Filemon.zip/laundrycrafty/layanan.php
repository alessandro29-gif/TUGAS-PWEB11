<?php
require_once "auth.php";
wajib_login("admin");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0);
    $nama = trim($_POST["nama_layanan"] ?? ""); $harga = (int)($_POST["harga_per_kg"] ?? 0);
    if ($nama == "" || $harga <= 0) {
        $_SESSION["pesan"] = "Nama layanan wajib diisi dan harga harus lebih dari 0.";
        $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0) {
        q("UPDATE layanan SET nama_layanan=?, harga_per_kg=? WHERE id_layanan=?", "sii", [$nama, $harga, $id]);
        $_SESSION["pesan"] = "Layanan berhasil diubah.";
    } else {
        q("INSERT INTO layanan (nama_layanan, harga_per_kg) VALUES (?,?)", "si", [$nama, $harga]);
        $_SESSION["pesan"] = "Layanan baru berhasil ditambahkan.";
    }
    header("Location: layanan.php"); exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    try {
        q("DELETE FROM layanan WHERE id_layanan=?", "i", [(int)$_POST["hapus"]]);
        $_SESSION["pesan"] = "Layanan berhasil dihapus.";
    } catch (Exception $e) {
        $_SESSION["pesan"] = "Layanan tidak bisa dihapus karena sudah dipakai transaksi.";
        $_SESSION["pesan_galat"] = 1;
    }
    header("Location: layanan.php"); exit;
}
$edit = null;
if (isset($_GET["edit"])) { $edit = satu("SELECT * FROM layanan WHERE id_layanan=?", "i", [(int)$_GET["edit"]]); }
$data = semua("SELECT * FROM layanan ORDER BY id_layanan");

$halaman = "layanan";
$judul_hero = "Layanan";
$teks_hero = "Atur jenis layanan dan harga per kilogram.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Layanan" : "Tambah Layanan"; ?></h3>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_layanan"] : 0; ?>">
<div class="row">
<div class="col-sm-6 form-group"><label for="nama_layanan">Nama layanan</label><input class="form-control" id="nama_layanan" name="nama_layanan" value="<?php echo e($edit["nama_layanan"] ?? ""); ?>" required></div>
<div class="col-sm-6 form-group"><label for="harga_per_kg">Harga per kg (Rp)</label><input type="number" min="1" class="form-control" id="harga_per_kg" name="harga_per_kg" value="<?php echo e($edit["harga_per_kg"] ?? ""); ?>" required></div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="layanan.php">Batal</a><?php } ?>
</form>
</div>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:520px">
<thead><tr><th>ID</th><th>Layanan</th><th>Harga / kg</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $l) { ?>
<tr>
<td><?php echo $l["id_layanan"]; ?></td>
<td class="nama"><?php echo e($l["nama_layanan"]); ?></td>
<td><?php echo rupiah($l["harga_per_kg"]); ?></td>
<td class="aksi-baris">
<a class="tombol-kecil" href="layanan.php?edit=<?php echo $l["id_layanan"]; ?>" style="text-decoration:none">Ubah</a>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus layanan ini?')"><button type="submit" name="hapus" value="<?php echo $l["id_layanan"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.nama_layanan.value.trim()=="" || Number(f.harga_per_kg.value) <= 0){ err.textContent="Nama wajib diisi dan harga harus lebih dari 0."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
