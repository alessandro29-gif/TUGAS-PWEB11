<?php
if( !isset($halaman) ){ $halaman = ""; }
if( !isset($judul_hero) ){ $judul_hero = "LaundryCrafty"; }
if( !isset($teks_hero) ){ $teks_hero = ""; }
$masuk = isset($_SESSION["id_user"]);
$admin = $masuk && $_SESSION["role"] == "admin";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#1B3A68">
<title><?php echo e($judul_hero); ?> - LaundryCrafty</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<a class="sr-only sr-only-focusable" href="#konten">Lewati ke konten utama</a>
<header class="site-header">
<div class="container">
<a class="brand-teks" href="index.php" aria-label="LaundryCrafty, ke halaman utama">LaundryCrafty</a>
<?php if($masuk){ ?>
<button type="button" class="nav-toggle" id="nav-toggle" aria-controls="menu-utama" aria-expanded="false" aria-label="Buka menu">
<span></span><span></span><span></span>
</button>
<nav aria-label="Menu utama">
<ul class="menu-utama" id="menu-utama">
<li<?php if($halaman == "index"){ echo ' class="aktif"'; } ?>><a href="index.php">Dashboard</a></li>
<li<?php if($halaman == "pelanggan"){ echo ' class="aktif"'; } ?>><a href="pelanggan.php">Pelanggan</a></li>
<li<?php if($halaman == "transaksi"){ echo ' class="aktif"'; } ?>><a href="transaksi.php">Transaksi</a></li>
<?php if($admin){ ?>
<li<?php if($halaman == "layanan"){ echo ' class="aktif"'; } ?>><a href="layanan.php">Layanan</a></li>
<li<?php if($halaman == "laporan"){ echo ' class="aktif"'; } ?>><a href="laporan.php">Laporan</a></li>
<?php } ?>
<li class="tombol-masuk"><a href="logout.php">Keluar (<?php echo e($_SESSION["username"]); ?>)</a></li>
</ul>
</nav>
<?php } ?>
</div>
</header>
<main class="konten" id="konten">
<section class="hero-polos hero-kecil">
<div class="container">
<h1 class="hero-judul"><?php echo e($judul_hero); ?></h1>
<?php if($teks_hero != ""){ ?>
<p class="hero-teks"><?php echo e($teks_hero); ?></p>
<?php } ?>
</div>
</section>
<?php if(isset($_SESSION["pesan"])){ ?>
<div class="container"><div class="kotak-info<?php echo (isset($_SESSION["pesan_galat"]) ? ' galat' : ''); ?>" role="status"><?php echo e($_SESSION["pesan"]); ?></div></div>
<?php unset($_SESSION["pesan"], $_SESSION["pesan_galat"]); } ?>
