<?php
require_once "auth.php";
wajib_login();
$jml_pelanggan = satu("SELECT COUNT(*) AS n FROM pelanggan")["n"];
$jml_transaksi = satu("SELECT COUNT(*) AS n FROM transaksi")["n"];
$jml_proses    = satu("SELECT COUNT(*) AS n FROM transaksi WHERE status = 'Proses'")["n"];
$hari_ini      = satu("SELECT COALESCE(SUM(total_harga),0) AS n FROM transaksi WHERE tanggal_masuk = CURDATE()")["n"];

$label = []; $nilai = [];
for ($i = 6; $i >= 0; $i--) {
    $tgl = date("Y-m-d", strtotime("-$i day"));
    $r = satu("SELECT COALESCE(SUM(total_harga),0) AS n FROM transaksi WHERE tanggal_masuk = ?", "s", [$tgl]);
    $label[] = date("d/m", strtotime($tgl));
    $nilai[] = (int)$r["n"];
}
$terbaru = semua("SELECT t.*, p.nama, l.nama_layanan FROM transaksi t JOIN pelanggan p ON p.id_pelanggan = t.id_pelanggan JOIN layanan l ON l.id_layanan = t.id_layanan ORDER BY t.id_transaksi DESC LIMIT 5");

$halaman = "index";
$judul_hero = "Dashboard";
$teks_hero = "Ringkasan usaha laundry hari ini.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="baris-sama">
<div class="col-sm-6 col-md-3"><div class="kartu-statistik"><div class="nilai"><?php echo $jml_pelanggan; ?></div><p class="label">Pelanggan</p></div></div>
<div class="col-sm-6 col-md-3"><div class="kartu-statistik biru"><div class="nilai"><?php echo $jml_transaksi; ?></div><p class="label">Total transaksi</p></div></div>
<div class="col-sm-6 col-md-3"><div class="kartu-statistik bulan"><div class="nilai"><?php echo $jml_proses; ?></div><p class="label">Cucian sedang diproses</p></div></div>
<div class="col-sm-6 col-md-3"><div class="kartu-statistik gelap"><div class="nilai"><?php echo rupiah($hari_ini); ?></div><p class="label">Pendapatan hari ini</p></div></div>
</div>

<h2>Pendapatan 7 Hari Terakhir</h2>
<div class="kartu-form" style="margin-bottom:40px">
<div class="grafik-kotak"><canvas id="grafik" aria-label="Grafik pendapatan 7 hari terakhir" role="img"></canvas></div>
</div>

<h2>Transaksi Terbaru</h2>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:640px">
<thead><tr><th>No</th><th>Pelanggan</th><th>Layanan</th><th>Total</th><th>Status</th></tr></thead>
<tbody>
<?php foreach ($terbaru as $t) { ?>
<tr>
<td><?php echo $t["id_transaksi"]; ?></td>
<td class="nama"><?php echo e($t["nama"]); ?></td>
<td><?php echo e($t["nama_layanan"]); ?></td>
<td><?php echo rupiah($t["total_harga"]); ?></td>
<td><span class="lencana <?php echo kelas_status($t["status"]); ?>"><?php echo e($t["status"]); ?></span></td>
</tr>
<?php } ?>
<?php if (!$terbaru) { ?><tr><td colspan="5" class="kosong">Belum ada transaksi.</td></tr><?php } ?>
</tbody>
</table>
</div>
<p style="margin-top:20px"><a class="btn-utama" href="transaksi-form.php">+ Transaksi Baru</a></p>
</div>
</section>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById("grafik"), {
type: "bar",
data: {
labels: <?php echo json_encode($label); ?>,
datasets: [{ label: "Pendapatan (Rp)", data: <?php echo json_encode($nilai); ?>, backgroundColor: "#ECB44D", borderColor: "#191939", borderWidth: 3, borderRadius: 10 }]
},
options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});
</script>
<?php include "footer.php"; ?>
